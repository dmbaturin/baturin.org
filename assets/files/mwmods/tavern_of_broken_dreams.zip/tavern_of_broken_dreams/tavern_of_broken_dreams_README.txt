Tavern of Broken Dreams
=======================

A joke mod inspired by the Cafe of Broken Dreams special encounter from Fallout2.

A strange Nord is relaxing on a beach south of Tel Fyr (Azura's Cost [19, -3]).
He can take you to a place where characters who are in the data files but aren't
found anywhere in the game gather to complain about it.

Ask the characters about the usual "Background", "My Trade", "Little advice", and "Latest rumors" topics
to learn their stories as I imagined them.

Cinia Urtius (the master trainer in medium armor that developers forgot to include) is not included because
Morrowind Patch Project and similar unofficial patches include her.

I kept the inventories and services of the NPCs intact, and only lowered their fight level if necessary
to make them non-hostile.

## Licensing

Assuming Bethesda's EULA doesn't prevent it, the mod is licensed under CC-BY 4.0 International.

Author: Daniil Baturin <daniil at baturin dot org>
