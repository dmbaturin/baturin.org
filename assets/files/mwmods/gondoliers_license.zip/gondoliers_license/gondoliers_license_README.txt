Gondolier's License
===================

This mod for The Elder Scrolls III: Morrowind allows you to acquire
the unique shirt and helm worn by Vivec gondoliers in an immersive way.

## Motivation

The distinctive shirt and helm worn by Vivec gondoliers are not found anywhere else in the game,
so it could only be acquired in rather non-immersive ways, including:

* Murdering a gondolier.
* Using the console.
* Installing a mod that places it in an arbitrary location without explaining how it got there.

What do you do if you absolutely need a gondolier costume for a Tales and Tallows party
but your character is neither a serial killer nor a shameless cheater?

I couldn't find a satisfactory solution so I made this mod. Besides, gondoliers themselves
must get that gear somewhere and the game lore says nothing about it.

## Walkthrough

Ask gondoliers for "little advice". Eventually (pretty soon in fact) they will caution you
about unlicensed gondoliers and tell you about license requirements.

Once you know about it (i.e. your character knows the "gondolier's license" topic),
visit Odres Uvaren in the Justice Offices. He shares his office with Aroa Nethalen,
across the room with Suryn Athones, the guy you are supposed to kill for an Imperial Legion quest
(which is why I placed Odres in the other room, so that you can still kill Suryn without
witnesses).

Talk to him about "gondolier's license" and answer his questions about Vivec geography.
If you pass his test, you can pay the license fee (200 drakes) and have the shirt and the helm
issued to you.

## Requirements

The mod only requires Morrowind.esm

## Licensing

Assuming Bethesda's EULA doesn't prevent it, the mod is licensed under CC-BY 4.0 International.

Author: Daniil Baturin <daniil at baturin dot org>
