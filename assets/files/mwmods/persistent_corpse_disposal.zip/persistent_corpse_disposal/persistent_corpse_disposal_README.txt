Persistent Corpse Disposal
==========================

## Synopsis

In Morrowind, corpses are normally removed after three days. That's bad for "solve a murder"
and "recover an item" quests, which is why some corpses are marked as persistent so that they are not
cleaned up before you have a chance to find them.

Unfortunately, there's no way to modify the "corpses persist" flag at run time and let them
decay naturally when they are no longer needed. This means those bodies are left in place forever,
so you can't claim the house of a murder victim after bringing their murdered to justice...
not without having a macabre decoration you cannot remove. Not so good for suspension of disbelief.

This mod attempts to solve that immersion issue by forcibly removing those bodies
when they are no longer needed for a quest.

## Implementation

The cleanup is done in the dialog scripts attached to topic infos or greetings that set the journal entry
for the last quest stage where the corpse was still relevant.

I chose to do it that way for three reasons:
1. To avoid adding a global script that runs every frame.
2. To make sure corpses don't disappear into thin air while you are looking.
3. To avoid messing up people's saves, especially if they use permanent corpses as infinite capacity containers.

Unfortunately, that means this mod will conflict with other mods that modify dialog entries
for the same quests.

To make it easier to predict conflicts and possibly implement a global script version in the future,
all affected corpses are listed below.

## Compatibility

This mod is fully supported in OpenMW.

The main issue is that the original engine cannot modify actors not currently loaded in the game,
so sometimes `"NPC name"->disable` may have no effect. OpenMW doesn't have this problem,
so it will correctly remove the corpse of Ralen Hlaalo if you solve his murder through
Larius Varro's quest without ever visiting his manor.

Feel free to report any issues to me, just note that some of them may not be correctable in the vanilla engine.

## Affected corpses

### Processus Vitellius

The taxman found dead near Seyda Neen.

His body is removed when you complete Death of a Taxman one way or another
(either bring the murderer to justice or side with him).

### Dahrk Mezalf

Still alive (kinda), haunting the Dwemer ruin of Bthungthumz.

His corpse is removed after you bring Baladas Demnevanni his ring.

### Ralen Hlaalo

Lying dead in Balmora, Hlaalo Manor.

His corpse is removed after you solve his murder.

### Ernil Omoran

The dead drug dealer whose body lies just north of Balmora, under a stone arc.

His corpse is removed after you bring his note to Tsiya.

### Telvanni in Shishi

The dead Telvanni, namely: Aditte Oges, Amring, Celegil, Indrel, Lanie Endre, Marielle Amedee.

Their corpses are removed after you complete the "Shishi" quest for Aryon (Telvanni side)
or "Shishi Report" for Theldyn Virith (Redoran side).

### Hlaalu in Odirniran

The dead Hlaalu, namely: Farare Othril, Talmsa Falas.

Their corpses are removed when you complete the "Telvanni at Odirniran" quest to Edryno Arethi
or complete the "Odirniran" quest for Aryon.

### Fallen heroes of the Temple

* Feril Salmyn, the unfortunate ordinator who met his death in Kogoruhn.
* Mendel Eves, the buoyant armiger who fell in a battle in Tureynulal.
* Voruse Bethrimo, the buoyant armiger who (unsurprisingly) never made it alive out of Dagoth Ur's inner tower.

Their corpses are removed when you bring their lost relics to Uvoo Llaren at the Ghostgate temple.

### Mansilamat Vabdas

The miner murdered by an Imperial Legion soldier guarding the Gnisis egg mine.

His corpse is removed when you complete the Widow Vabdas' Deed quest, though technically you only
need the axe for the quest, his body is just a part of the crime scene.

### Nads Tharen

The thief who died in Vivec, St. Delyn Canal South-Two under mysterious circumstances.

His body is removed when you bring his key to Gentleman Jim Stacey.

### Irer Nervion

The guy who died trying to kill Dagoth Tanis in Falasmaryon.

His corpse is removed when you complete the "Slay Dagoth Tanis" quest for Faral Retheran.

### Ruran Stoine

The breton rogue found dead underwater in the cavern of Mallapi.

His body is removed when you complete the quest for Lorbumol gro-Aglakh in Vivec's Fighters Guild.

### Urjorad

The Imperial Cult crusader who tried to kill Carecalmo in Ashalmimilkala but failed.

His body is removed when you complete the Scroll of Fiercely Roasting quest,
though the scroll is next to his body rather than in his inventory.

### Elberoth (Bloodmoon)

The captain of the original supply ship.

His corpse is removed when you report the loss of the supply ship to Carnius.

### M'nashi (Bloodmoon)

The Khajit who worked with Uncle Sweetshare and fell victim of an occupational hazard.

His corpse is removed when you complete The Moon Sugar Mystery.

### The crew of the Patchwork Airship (Bloodmoon)

Namely: Swims-In-Swells, Captain Roberto Jodoin, Francois Marquardt, Manabi Virith, Manolos Virith.

## Unaffected corpses

### Smugglers in the Nerano ancestral tomb

Three dead smugglers: Danders, Moris, Ursine. Presumably victims of Calvario the vampire.
They aren't actually needed for any quest, so there's no clear trigger for removing them.
Besides, there are mods that add a quest that requires them (e.g. LGNPC Pax Redoran),
so that would only create more conflicts.

### Generic corpses

Generic bodies named "Dead Hero", "Dead Adventurer" etc. are not removed because there are
no obvious triggers for their removal.
