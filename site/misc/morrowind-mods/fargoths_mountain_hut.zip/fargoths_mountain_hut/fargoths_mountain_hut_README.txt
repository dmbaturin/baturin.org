Fargoth's Mountain Hut
======================

A house mod for The Elder Scrolls III: Morrowind.
Rather, a deconstruction of the house mod genre. In simpler terms, the worst house mod ever.

# Motivation

Remember all those mods where you get an improbably nice house for free.
How many of them have you seen already?

Why anyone would abandon a perfectly good house, or give it away for free?
If it's free, perhaps it's more trouble than it's worth?

My goal was to make a house no one would want to use:
* Very inconvenient location.
* Right between two leveled creature spawning points.
* Small storage space.
* Occupied by an arrogant squatter.
* The squatter attacks you when you try to use the bed or the only available container.
* You cannot permanently evict the squatter.

But hey, at least it's free.

# Walkthrough

Talk to your old friend Fargoth in Seyda Neen. If he likes you enough (disposition > 80),
he will share a story of getting scammed by a real estate agent who sold him
a home "near Maar Gan" for just 500 drakes, which turned out to be much farther away
in the middle of the wilderness too dangerous for everyone but experienced adventurers like you.

He gives you a key and vague directions, and that's all you get, since he has never even
been to the hut himself. When you find it, you'll wish you haven't wasted your time either.

## Directions for cheaters

coe 4, 12
coc "Fargoth's Hut"

## Directions for hikers

Take the road out of Maar Gan that goes past the Huleen's hut. Take the right turn
and go to the valley where Kogoruhn is located. Ignore Kogoruhn, stick close to the mountain,
and take the trail up the slope, marked by a bittergreen plant on the left.
Follow the trail along the Ghostfence, cross two rope bridges, and you will reach a foyada.
From the foyada you should be able to see the hut.
If you don't want to use levitation, you can go up the trail, one or two Ghostfence sections further,
and descdend from there.

If you are an expert in dwemer ruins, Bhthuand is the best landmark, the hut is due south of it.

## Notes

The squatter respawns every three days so you can repeat the masochism cycle as many times as you want.
When the squatter is dead you can use the bed and the container normally, and you will not be attacked
in your sleep. Maybe I should fix this oversight, though it will need a custom respawn script
instead of the built-in respawn mechanism.

# Conflicts

The mod makes changes to cells [4,12] and [4,13] in the Ashlands, which I hope are isolated and obscure enough
that no one else modified them.

# Requirements

Only requires Morrowind.esm
The mod was cleaned with TESTool.

# License

Assuming Bethesda's EULA doesn't prevent it, the mod is licensed under CC-BY 4.0 International.

Author: Daniil Baturin <daniil at baturin dot org>
