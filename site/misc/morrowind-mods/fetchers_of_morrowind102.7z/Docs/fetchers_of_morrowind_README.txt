Fetchers of Morrowind
=====================

Fetchers of Morrowind is a quest mod for The Elder Scrolls III: Morrowind.

Fetchers of Morrowind is a company that finds items and delivers them to customers.
They are looking for adventurers who can find unusual items. To start working with them,
talk to Marthe Rane in Vivec, Foreign Quarter Upper Wasteworks.

## Motivation

Find out whether giving characters background and motivation relives the tedium
of "fetch me an item" quests.

## Requirements

The mod only requires Morrowind.esm

## Licensing

Assuming Bethesda's EULA doesn't prevent it, the mod is licensed under CC-BY 4.0 International.

Author: Daniil Baturin <daniil at baturin dot org>


v 1.02 changes /abot
- cleaned (mostly some empty deleted dialog INFO)
- moved to a new "Vivec, Foreign Quarter Fetchers of Morrowind" cell linked to
Foreign Quarter Upper Waistworks interior cell, so it does not conflict 
with standard Foreign Quarter Upper Waistworks path grid any more

