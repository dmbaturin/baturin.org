Immersive Imperial Skirt
========================

Many Imperial Legion members wear distinctive skirts with their armor.
Imperial guards wear common imperial skirts, and some Legion officers wear
an imperial templar skirts with a different design.

Yet there is no way to obtain either skirt.
Not even becoming the Knight of the Imperial Dragon will get you one.

Something has to be done about it.

# Playing the mod

Talk to any Imperial Legion member about "latest rumors". They will comment
on the unfortunate situation with skirts and tell you that General Darius
wants to fix it.

Then go to Gnisis, Madach Tradehouse, and talk to Darius.

After that, talk to clothiers in different towns. There are two possible outcomes:
* find a civilian clothier who will agree to make skirts
* recruit a fulltime clothier for the Legion

If the contract goes to a civilian clothier, you will receive one of each skirts.
However, if you find a fulltime clothier, he will move to the Madach tradehouse
with a restocking supply of those skirts.

Which clothiers should you talk to? Those in the cities most friendly towards the Empire of course.

## Requirements

The mod only requires Morrowind.esm

## Licensing

Assuming Bethesda's EULA doesn't prevent it, the mod is licensed under CC-BY 4.0 International.

Author: Daniil Baturin <daniil at baturin dot org>
